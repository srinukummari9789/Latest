package com.capstone.FeedbackManagementSystem.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capstone.FeedbackManagementSystem.model.Dashboard;
import com.capstone.FeedbackManagementSystem.model.Event;
import com.capstone.FeedbackManagementSystem.service.EventService;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/events")
public class EventController {
	
	@Autowired
	public EventService eventService;
	
	
	@PostMapping(value = "/addEvent", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	@PreAuthorize("hasRole('ADMIN')")
	public Mono<ResponseEntity<Event>> saveEvent(@RequestBody Event event) {
		return eventService.saveEvents(event).map(savedEvent -> ResponseEntity.ok(savedEvent));
	}
	
	@GetMapping(value = "/allEvents", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	@PreAuthorize("hasRole('PMO') or hasRole('ADMIN')")
	public Flux<Event> getAllEvents() {
		return eventService.getAllEvents();
	}
	
	@GetMapping(value = "/eventDetails", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	@PreAuthorize("hasRole('PMO') or hasRole('ADMIN') or hasRole('POC')")
	public Mono<Event> getEventDetails(@RequestParam Integer eventId) {
		return eventService.getEventDetailsById(eventId);
	}

	@GetMapping(value = "/deleteEvent", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	@PreAuthorize("hasRole('ADMIN')")
	public Mono<Void> deleteEvent(@RequestParam Integer eventId) {
		return eventService.deleteEvent(eventId);
	}

	@GetMapping(value = "/deleteAllEvents", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	@PreAuthorize("hasRole('ADMIN')")
	public Mono<Void> deleteAllEvents() {
		return eventService.deleteAllEvents();
	}
	
	@GetMapping(value = "/getDashboardData", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
	@PreAuthorize("hasRole('PMO') or hasRole('ADMIN')")
	public Flux<Dashboard> dashboardData() {
		Dashboard dashBoard = new Dashboard();
		Mono<Long> m1 = eventService.getAllEvents().count();
		m1.subscribe(s -> dashBoard.setCount(Integer.parseInt(s.toString())));
		// dashBoard.setCount(15);
		Mono<Integer> m2 = eventService.getAllEvents().map(x -> x.getTotalVollunteers()).reduce(0, (a, b) -> a + b);

		m2.subscribe(s -> dashBoard.setTotalVolunteers(Integer.parseInt(s.toString())));

		Mono<Integer> m3 = eventService.getAllEvents().map(x -> x.getLivesImpacted()).reduce(0, (a, b) -> a + b);
		m3.subscribe(s -> dashBoard.setLivesImpacted(Integer.parseInt(s.toString())));
		Mono<Integer> m4 = eventService.getAllEvents().map(x -> x.getTotalParticipants()).reduce(0, (a, b) -> a + b);
		m4.subscribe(s -> dashBoard.setTotalParticipants(Integer.parseInt(s.toString())));

		List<Dashboard> list = new ArrayList<>();
		list.add(dashBoard);

		return Flux.fromIterable(list);
	}

}
