package com.capstone.FeedbackManagementSystem.jwt.model;

import lombok.Data;

@Data //@NoArgsConstructor @AllArgsConstructor @ToString
public class Message {
	
	private String content;
	public Message(String content) {
		this.setContent(content);
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}

}
