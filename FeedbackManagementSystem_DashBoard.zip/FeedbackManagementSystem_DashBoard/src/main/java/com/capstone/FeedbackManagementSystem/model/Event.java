package com.capstone.FeedbackManagementSystem.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Document 
@Data 
@AllArgsConstructor
@NoArgsConstructor
public class Event {
@Id
private int eventId;

private String eventName;

private String eventDate;

private String businessUnit;

private String venue;

private int totalVollunteers;

private int totalParticipants;

private int livesImpacted;

private int vallunteerHours;

private int travelHours;
public int getEventId() {
	return eventId;
}
public void setEventId(int eventId) {
	this.eventId = eventId;
}
public String getEventName() {
	return eventName;
}
public void setEventName(String eventName) {
	this.eventName = eventName;
}
public String getEventDate() {
	return eventDate;
}
public void setEventDate(String eventDate) {
	this.eventDate = eventDate;
}
public String getBusinessUnit() {
	return businessUnit;
}
public void setBusinessUnit(String businessUnit) {
	this.businessUnit = businessUnit;
}
public String getVenue() {
	return venue;
}
public void setVenue(String venue) {
	this.venue = venue;
}
public int getTotalVollunteers() {
	return totalVollunteers;
}
public void setTotalVollunteers(int totalVollunteers) {
	this.totalVollunteers = totalVollunteers;
}

public int getTotalParticipants() {
	return totalParticipants;
}
public void setTotalParticipants(int totalParticipants) {
	this.totalParticipants = totalParticipants;
}


public int getLivesImpacted() {
	return livesImpacted;
}
public void setLivesImpacted(int livesImpacted) {
	this.livesImpacted = livesImpacted;
}
public int getVallunteerHours() {
	return vallunteerHours;
}
public void setVallunteerHours(int vallunteerHours) {
	this.vallunteerHours = vallunteerHours;
}
public int getTravelHours() {
	return travelHours;
}
public void setTravelHours(int travelHours) {
	this.travelHours = travelHours;
}



}
