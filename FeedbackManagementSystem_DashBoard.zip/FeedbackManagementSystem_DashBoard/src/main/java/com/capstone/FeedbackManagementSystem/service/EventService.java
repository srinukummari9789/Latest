package com.capstone.FeedbackManagementSystem.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capstone.FeedbackManagementSystem.model.Event;
import com.capstone.FeedbackManagementSystem.repository.EventRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class EventService {
	@Autowired
	public EventRepository eventRepository;
	
	public Flux<Event> getAllEvents(){
		return eventRepository.findAll();
	}
	public Mono<Event> getEventDetailsById(Integer id){
		return eventRepository.findById(id);
	}
	
	public Mono<Event> saveEvents(Event e) {
		return eventRepository.save(e);
	}
	
	public Mono<Void> deleteEvent(int eventId) {
		return eventRepository.deleteById(eventId);
	}
	
	public Mono<Void> deleteAllEvents() {
		return eventRepository.deleteAll();
	}
	
	
}
