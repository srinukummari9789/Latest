package com.capstone.FMS.FeedbackManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FeedbackManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
