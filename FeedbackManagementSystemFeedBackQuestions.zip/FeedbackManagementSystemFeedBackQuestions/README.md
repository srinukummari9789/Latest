# Feedback Management System FeedBack Questions application

This application is used get the FeedBack from the Participants

# REST API

The REST APIs to Feedback Management System FeedBack Questions app is described below.

================================ Feedback Questions REST API ===================================

## Get All Questions From DataBase

### Request

`GET /question/`

	 http://localhost:8080/question/
	 
### Response 

	[
	    {
	        "questionId": 1,
	        "questionName": "Name of the last event you have attended?",
	        "answers": [],
	        "feedbackType": null
	    },
	    {
	        "questionId": 2,
	        "questionName": "How many days event will be active?",
	        "answers": [],
	        "feedbackType": null
	    },
	    {
	        "questionId": 3,
	        "questionName": "How many days event will be inactive?",
	        "answers": [],
	        "feedbackType": {
	            "feedbackId": 1,
	            "feedbackType": "good"
	        }
	    }
	]

## Get FeedBack Questions By id

### Request

'GET' /question/feedback/{id}

	http://localhost:8080/question/feedback/1
	
### Response

	[
    {
        "questionId": 3,
        "questionName": "How many days event will be inactive?",
        "feedbackId": 1
    }
]


## Save Feedback Questions

### Request

'POST' /question/

	http://localhost:8080/question/
	
	## Request Body
	
		{
			"questionName": "How many days event will be inactive?",
			"feedbackId": "1"
		}
	
### Response

	{
    	"questionId": 4,
    	"questionName": "How many days event will be inactive?",
    	"feedbackId": 1
	}
	
	
## Delete Feedback questions By Id

### Request

'DELETE' /question/

	http://localhost:8080/question/4
	
### Response
	
	Http Status Code : 200 Ok
	
	
## Get Feedback questions By QuestionId

### Request

'GET /question/{id}'
	
	http://localhost:8080/question/3
	
### Response

	{	
		{
	    "questionId": 3,
	    "questionName": "How many days event will be inactive?",
	    "answers": [],
	    "feedbackType": {
	        "feedbackId": 1,
	        "feedbackType": "good"
	    }
	}
	
	
	
================================ Feedback Answers REST API ===================================

## Save Feedback Answers

### Request

'POST /answer/'
	
	http://localhost:8080/answer/
	
	## Request Body
	
	{
		"answerName": "CTS HealthAwerness Event",
		"questionId": "1"
	}
	
### Response

	{
    	"answerId": 5,
    	"answerName": "CTS HealthAwerness Event",
    	"questionId": 1
	}
	
	
## Save multiple Feedback Answers

### Request

'PATCH /answer/saveall/{questionId}'
	
	http://localhost:8080/answer//saveall/{questionId}
	
	## Request Body
	
	{
		"answerList" : [{"answerName": "what about your Health", "questionId": "2"},
					{"answerName": "Health is more imp", "questionId": "1"}],
		"feedbackId" : "2"
	}
	
### Response

	[
	    {
	        "answerId": 6,
	        "answerName": "what about your Health",
	        "questionId": 2
	    },
	    {
	        "answerId": 7,
	        "answerName": "Health is more imp",
	        "questionId": 1
	    }
	]

	
## Delete Feedback Answers By Id

### Request

'DELETE /answer/{id}'
	
	http://localhost:8080/answer/1
	
### Response

	Http Status : 200 ok
	

## Delete Feedback Answers By Id

### Request

'GET /answer/{questionId}'
	
	http://localhost:8080/answer/1
	
### Response

	[
	    {
	        "answerId": 5,
	        "answerName": "CTS HealthAwerness Event",
	        "questionId": 1
	    },
	    {
	        "answerId": 7,
	        "answerName": "Health is more imp",
	        "questionId": 1
	    }
	]
	
	
	
	
================================= Feedback Type ======================================

## Get Feedback Type From DataBase

### Request

`GET /feedbackType/`

	 http://localhost:8080/feedbackType/
	 
### Response 

	[
	    {
	        "feedbackId": 1,
	        "feedbackType": "good"
	    },
	    {
	        "feedbackId": 2,
	        "feedbackType": "bad"
	    },
	    {
	        "feedbackId": 3,
	        "feedbackType": "excelent"
	    },
	    {
	        "feedbackId": 4,
	        "feedbackType": "moderate"
	    }
	]