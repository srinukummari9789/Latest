package com.capstone.feedbacksystem.repository;

import org.springframework.data.repository.reactive.ReactiveCrudRepository;

import com.capstone.feedbacksystem.domain.FeedbackType;

public interface FeedbackRepository extends ReactiveCrudRepository<FeedbackType, Long>{

}
